﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraEstadistica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string[] numerosStr = txtDatos.Text.Split(new[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            List<double> numeros = new List<double>();

            foreach (string numeroStr in numerosStr)
            {
                if (double.TryParse(numeroStr, out double numero))
                {
                    numeros.Add(numero);
                }
            }

            if (numeros.Count > 0)
            {
                double media = CalcularMedia(numeros);
                double mediana = CalcularMediana(numeros);
                List<double> moda = CalcularModa(numeros);
                double desviacionEstandar = CalcularDesviacionEstandar(numeros);
                double rango = CalcularRango(numeros);

                lblMedia.Text = "Media: " + media.ToString("0.##");
                lblMediana.Text = "Mediana: " + mediana.ToString("0.##");
                lblModa.Text = "Moda: " + string.Join(", ", moda.Select(x => x.ToString("0.##")));
                lblDesviacionEstandar.Text = "Desviación Estándar: " + desviacionEstandar.ToString("0.##");
                lblRango.Text = "Rango: " + rango.ToString("0.##");
            }
            else
            {
                MessageBox.Show("Ingrese al menos un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private double CalcularMedia(List<double> numeros)
        {
            return numeros.Sum() / numeros.Count;
        }

        private double CalcularMediana(List<double> numeros)
        {
            numeros.Sort();

            if (numeros.Count % 2 == 0)
            {
                int indice1 = numeros.Count / 2 - 1;
                int indice2 = numeros.Count / 2;
                return (numeros[indice1] + numeros[indice2]) / 2;
            }
            else
            {
                int indice = numeros.Count / 2;
                return numeros[indice];
            }
        }

        private List<double> CalcularModa(List<double> numeros)
        {
            Dictionary<double, int> conteo = new Dictionary<double, int>();

            foreach (double numero in numeros)
            {
                if (conteo.ContainsKey(numero))
                    conteo[numero]++;
                else
                    conteo[numero] = 1;
            }

            int maximo = conteo.Values.Max();

            return conteo.Where(kv => kv.Value == maximo).Select(kv => kv.Key).ToList();
        }

        private double CalcularDesviacionEstandar(List<double> numeros)
        {
            double media = CalcularMedia(numeros);
            double sumatoria = numeros.Sum(numero => Math.Pow(numero - media, 2));
            double varianza = sumatoria / numeros.Count;
            return Math.Sqrt(varianza);
        }

        private double CalcularRango(List<double> numeros)
        {
            return numeros.Max() - numeros.Min();
        }
    }
}
