﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_1_3er_bimestre
{
    public class Plantilla{
        string nombre ;
        string apellido;
        string identificacion;

        public Plantilla(string n, string a, string i)
        {
            nombre = n;
            apellido = a;
            identificacion = i;
        }
                




        public void nombrar ()
        {
            System.Windows.Forms.MessageBox.Show("El nombre es:" + nombre);
            System.Windows.Forms.MessageBox.Show("El apellido es :" + apellido);
            System.Windows.Forms.MessageBox.Show("El no de id. es:" + identificacion);
        }
    




    }
   
}


