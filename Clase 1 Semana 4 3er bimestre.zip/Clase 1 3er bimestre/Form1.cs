﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clase_1_3er_bimestre
{
    public partial class Form1 : Form
    {
        Plantilla alummno = new Plantilla("Tito","Garcia","2023");// instanciar objeto
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnnombrar_Click(object sender, EventArgs e)
        {
            alummno.nombrar();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Admintrador frm2 = new Admintrador();
            frm2.Show();
        }
    }
}
