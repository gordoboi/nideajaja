﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();// Cierra el programa
        }

        private void btnSuma_Click(object sender, EventArgs e)
        {
            double Num1 = double.Parse(txtNum1.Text);
            double Num2 = double.Parse(txtNum2.Text);

            double result = Num1 + Num2;

            txtResultado.Text = result.ToString();
        }

        private void btnDivision_Click(object sender, EventArgs e)
        {
            double Num1 = double.Parse(txtNum1.Text);
            double Num2 = double.Parse(txtNum2.Text);

            double result = Num1 / Num2;

            if (Num2 == 0)
            {
                MessageBox.Show("No es posible realizar la division", "ERROR");
            }
            else { txtResultado.Text = result.ToString(); }
            txtResultado.Text = result.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnMultiplicacion_Click(object sender, EventArgs e)
        {
            double Num1 = double.Parse(txtNum1.Text);
            double Num2 = double.Parse(txtNum2.Text);

            double result = Num1 * Num2;
            txtResultado.Text = result.ToString();
        }

        private void btnResta_Click(object sender, EventArgs e)
        {
            double Num1 = double.Parse(txtNum1.Text);
            double Num2 = double.Parse(txtNum2.Text);

            double result = Num1 - Num2;
            txtResultado.Text = result.ToString();
        }
    }
}
