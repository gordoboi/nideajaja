﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Archivos_Liceo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            string texto = txtNombre.Text;
            string ruta = @"C:\Users\gordo\OneDrive\Escritorio\Visual\" + texto + ".txt";
            using(StreamWriter sw=new StreamWriter(ruta)) 
            {
            sw.WriteLine(txtComentario.Text); 
            }
            MessageBox.Show("Se creo correctamente");
        }
    }
}
